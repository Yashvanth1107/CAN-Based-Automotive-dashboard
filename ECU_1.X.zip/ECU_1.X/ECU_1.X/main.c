#include <xc.h>
#include "ADC.h"
#include "clcd.h"
#include "can.h"
#include "uart.h"
#include "MSG_ID.h"
#include "digital_keypad.h"

int get_speed()
{
    unsigned int adc_value, speed;
    char speed_str[3];
    
    adc_value = read_adc(CHANNEL4);       // Read analog input from channel 4
    speed = adc_value / 10.33;            // Convert ADC value to approximate speed
    speed_str[0] = (speed / 10) + '0';    // Extract tens digit
    speed_str[1] = (speed % 10) + '0';    // Extract ones digit
    speed_str[2] = '\0';                  // Null-terminate the string
    
    can_transmit(SPEED_MSG_ID, speed_str, 2); // Transmit speed data via CAN bus
    __delay_ms(80);                       // Small delay to stabilize transmission
}

void main(void) 
{
    init_adc();               // Initialize ADC module
    init_digital_keypad();    // Initialize digital keypad
    init_clcd();              // Initialize character LCD
    init_can();               // Initialize CAN communication module
    
    int i = 0, speed;
    char gear[9][3] = {"ON", "GN", "G1", "G2", "G3", "G4", "G5", "GR", "c_"}; // Gear states
    unsigned gear_index = 0;  // Starting gear index (ON state)
    
    while(1)
    {
        get_speed();  // Continuously read and send current speed
        
        can_transmit(GEAR_MSG_ID, gear[gear_index], 2); // Send current gear status over CAN
        __delay_ms(80); // Delay to avoid bus overload
        
        unsigned char key = read_digital_keypad(STATE_CHANGE); // Read key press
        
        if(gear_index == 8) // If it in collision state
        {
            if(key == SWITCH1 || key == SWITCH2)
            {
                gear_index = 0; // Return to initial (ON) state
            }
        }
        else
        {
            if(key == SWITCH1) // If switch1 pressed
            {
                if(gear_index < 7)
                    gear_index++; // Shift gear up
            }
            else if(key == SWITCH2) // If switch2 pressed
            {
                if(gear_index > 0)
                    gear_index--; // Shift gear down
            }
        }
        
        if(key == SWITCH3)
        {
            gear_index = 8; // Activate collision mode
        }
    }

    return;
}
